﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models
{
    public class DelagatedEmpFromAndroid
    {
        public string EmpName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}
