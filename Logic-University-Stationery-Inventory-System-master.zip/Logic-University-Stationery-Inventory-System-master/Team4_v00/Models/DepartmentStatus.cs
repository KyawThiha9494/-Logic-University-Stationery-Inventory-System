﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models
{
    public enum DepartmentStatus
    {
        Active,
        Cancelled
    }
}
