﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models
{
    public enum CollectionPoint
    {
        StationeryStore,
        ManagementSchool,
        MedicalSchool,
        EngineeringSchool,
        ScienceSchool,
        UniversityHospital
    }
}
