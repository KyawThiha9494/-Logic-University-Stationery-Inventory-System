﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models.AndroidDTOs
{
    public class TestDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
