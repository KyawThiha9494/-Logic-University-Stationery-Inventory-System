﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ben_Project.Models
{
    public enum DeptRole
    {
        Employee,
        DeptHead,
        Contact,
        DeptRep,
        StoreClerk,
        StoreSupervisor,
        StoreManager,
        DelegatedEmployee
    }
}
